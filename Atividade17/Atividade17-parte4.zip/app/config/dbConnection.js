const sql = require('mssql');
var connSQLServer = function(){
  const sqlConfig =
    {
        user: 'BD2221011',
        password: 'Dudu@1590',
        database: 'BD',
        server: 'apolo',
        driver:'msnodesql8',
        options:
        {
            encrypt: false,
            trustServerCertificate: true // se você não tiver um certificado de servidor configurado
        }
    }
    return sql.connect(sqlConfig);
}
 
module.exports = function(){
  console.log('O autload carregou o módulo de conexão com o bd');
  return connSQLServer;
}