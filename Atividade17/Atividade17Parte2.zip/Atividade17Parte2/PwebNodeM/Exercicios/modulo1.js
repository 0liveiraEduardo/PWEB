var texto = "Observe que esta mensagem vem do modulo";
module.exports = texto;