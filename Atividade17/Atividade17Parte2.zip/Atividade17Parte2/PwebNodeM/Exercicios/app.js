var app = require('./app/config/server');


var rotaAdicionarUsuario = require('./app/routes/adicionar_usuario');
rotaAdicionarUsuario(app);

var rotaCursos = require('./app/routes/cursos');
rotaCursos(app);

var rotaHistoria = require('./app/routes/historia');
rotaHistoria(app);

var rotaHome = require('./app/routes/home');
rotaHome(app);

var rotaProfessores = require('./app/routes/professores');
rotaHome(app);

app.listen(3000,function(){
    console.log("servidor iniciado");
});
