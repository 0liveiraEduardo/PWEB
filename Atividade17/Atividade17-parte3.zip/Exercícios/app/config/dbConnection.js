const sql = require('mssql');

module.exports = function () {
    const config = {
        user: 'BD2221011',
        password: 'Dudu@1590',
        database: 'BD',
        server: 'apolo',
        options: {
            encrypt: false,
            trustServerCertificate: true // se você não tiver um certificado de servidor configurado
        }
    }
    return sql.connect(config);
}
