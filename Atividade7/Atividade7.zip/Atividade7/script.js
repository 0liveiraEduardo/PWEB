var Computador, Usuario;

Computador = Math.random();

if (Computador < 0.33) {
    Computador = "Pedra";
} else if (Computador < 0.66) {
    Computador = "Papel";
} else {
    Computador = "Tesoura";
}

Usuario = prompt("Escolha: Pedra, Papel ou Tesoura.");

if (Computador === Usuario) {
    alert("Usuario: " + Usuario +
        "\nComputador: " + Computador +
        "\n\nEmpate!")
} else if ((Usuario === 'Pedra' && Computador === 'Tesoura') ||
    (Usuario === 'Tesoura' && Computador === 'Papel') ||
    (Usuario === 'Papel' && Computador === 'Pedra')) {
    alert("Usuario: " + Usuario +
        "\nComputador: " + Computador +
        "\n\nUsuario ganhou!")
} else {
    alert("Usuario: " + Usuario +
        "\nComputador " + Computador +
        "\n\n Voce perdeu!")
}