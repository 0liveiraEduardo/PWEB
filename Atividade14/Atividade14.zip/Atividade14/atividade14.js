document.addEventListener("DOMContentLoaded", function () {
    const textoInput = document.getElementById("texto");
    const maiusculasCheckbox = document.getElementById("maiusculasCheckbox");
    const minusculasCheckbox = document.getElementById("minusculasCheckbox");
    const resultado = document.getElementById("resultado");

    function transformarTexto() {
        let textoTransformado = textoInput.value;

        if (maiusculasCheckbox.checked) {
            textoTransformado = textoTransformado.toUpperCase();
            minusculasCheckbox.checked = false;
        }

        if (minusculasCheckbox.checked) {
            textoTransformado = textoTransformado.toLowerCase();
            maiusculasCheckbox.checked = false;
        }

        resultado.textContent = textoTransformado;
    }

    textoInput.addEventListener("input", transformarTexto);
    maiusculasCheckbox.addEventListener("change", transformarTexto);
    minusculasCheckbox.addEventListener("change", transformarTexto);
});