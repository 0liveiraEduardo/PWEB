function validarFormulario() {
    var form = document.getElementById("meuForm");
    var nome = form.elements["nome"].value;
    var email = form.elements["email"].value;
    var comentario = form.elements["comentario"].value;
    var pesquisa = form.elements["pesquisa"].value;

    if (nome.length < 10) {
        alert("O nome deve ter pelo menos 10 caracteres.");
        form.elements["nome"].focus();
        return false;
    }

    if (email.indexOf("@") == -1 || email.indexOf(".") == -1) {
        alert("O email deve conter os caracteres '@' e '.'.");
        form.elements["email"].focus();
        return false;
    }

    if (comentario.length < 20) {
        alert("O comentário deve ter pelo menos 20 caracteres.");
        form.elements["comentario"].focus();
        return false;
    }

    if (!pesquisa) {
        alert("Que bom que você voltou a visitar esta página!");
    } else {
        alert("Volte sempre a esta página!");
    }

    return true;
}