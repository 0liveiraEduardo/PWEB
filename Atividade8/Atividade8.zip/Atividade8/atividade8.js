var i = 0
total_idade = 0
masc = 0
fem = 0
qtd_pessimo = 0
qtd_otimo = 0
qtd_bom = 0
mais_velha = 0
mais_nova = 100

while (i <= 44) {
    idade = parseInt(prompt("Digite sua idade:"))
    sexo = prompt("Digite seu sexo:")
    opniao = prompt("Digite sua opniao:\n 1 = péssimo\n 2 = regular\n 3 = bom\n 4 = ótimo\n")
    //idade
    total_idade += idade
   
    if (idade > mais_velha)
        mais_velha = idade
    if (idade < mais_nova)
        mais_nova = idade

    //sexo
    if (sexo == "M" || sexo == "m")
        masc++
    else
        fem++

    //opniao
    if (opniao == "1")
        qtd_pessimo++
    else if (opniao == "4")
        qtd_otimo++
    else if (opniao == "3")
        qtd_bom++

    //i do looping
    i++
}

media_idade = total_idade / i
porcent = ((qtd_otimo + qtd_bom) / i)
alert("Média idade: " + media_idade)
alert("Pessoa mais velha: " + mais_velha)
alert("Pessoa mais nova: " + mais_nova)
alert("Pessoas que responderam péssimo: " + qtd_pessimo)
alert("Porcentagem ótimo e bom: " + ((qtd_otimo + qtd_bom) / i) * 100 + "%")
alert("Quantidade respostas mulheres: " + fem)
alert("Quantidade respostas homens: " + masc)