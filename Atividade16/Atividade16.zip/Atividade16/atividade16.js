function abrirCurso() {
    var selectBox = document.getElementById("cursos");
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;
    var confirmacao = confirm("Deseja abrir a página do curso de " + selectedValue + "?");

    if (confirmacao) {
        var url;
        switch (selectedValue) {
            case "Análise e Desenvolvimento de Sistemas":
                url = "analise_e_desenvolvimento.html";
                break;
            case "Fabricação Mecânica":
                url = "fabricacao_mecanica.html";
                break;
            case "Logística":
                url = "logistica.html";
                break;
            case "Sistemas Biomédicos":
                url = "sistemas_biomedicos.html";
                break;
            case "Projetos Mecânicos":
                url = "projetos_mecanicos.html";
                break;
            default:
                url = "";
        }
        if (url !== "") {
            window.open(url, "", "width=600,height=300");
        }
    }
}