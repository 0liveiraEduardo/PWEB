var num1, num2;
alert("Operacoes / Atividade6");
alert("Digite dois numeros: ");

num1 = parseFloat(prompt())
num2 = parseFloat(prompt())

alert("A soma dos dois é: " + (num1 + num2));
alert("A subtracao do primeiro pelo segundo é: " + (num1 - num2));
alert("O produto entre eles: " + (num1 * num2));
if (num2 == 0) {
    alert("Não e possivel dividir por 0")
}
else {
    alert("A divisao do primeiro pelo segundo " + (num1 / num2));
}
alert("O resto da divisao do primeiro pelo segundo: " + (num1 % num2));