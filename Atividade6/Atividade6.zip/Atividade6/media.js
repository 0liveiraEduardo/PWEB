alert("Media.html / Atividade 6")

var nome;
var nota1, nota2, nota3;
var media;

nome = prompt("Qual é o seu nome?");

alert("Seu nome é " + nome);

alert("Agora, digite as notas 1, 2 e 3: ")

nota1 = parseFloat(prompt());
nota2 = parseFloat(prompt());
nota3 = parseFloat(prompt());

media = ((nota1 + nota2 + nota3) / 3);

alert("Sua media é: " + media);